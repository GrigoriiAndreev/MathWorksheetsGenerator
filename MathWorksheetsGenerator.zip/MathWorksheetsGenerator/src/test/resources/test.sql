#insert into users (name, age, email) values ('greg123', '47', 'gandreyev@rambler.ru');
#select * from users;
select id, name from users where id = 2;
#update users set name = 'peter', age = 55 where id = 1;
#delete from users where id = 1;