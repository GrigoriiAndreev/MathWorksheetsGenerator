package MathPackage;

public class MainAbstractClass {

    String gradeRus;
    String gradeEng;
    String topicRus;
    String topicEng;
    String h2Rus;
    String h2Eng;
    String numberRus;
    String numberEng;
    String shortProblemDescriptionRus;
    String shortProblemDescriptionEng;
    String longProblemDescriptionRus;
    String longProblemDescriptionEng;
    int numbersRangeStart;
    int numbersRangeEnd;
    int totalPageOfWorksheets;

    static String readyFilesFolder = "";
    static String readyFilesFolderPdf = "";
    static String readyFilesFolderHtml = "";


//    public MainAbstractClass(
//            String gradeRus,
//            String gradeEng,
//            String topicRus,
//            String topicEng,
//            String h2Rus,
//            String h2Eng,
//            String numberRus,
//            String numberEng,
//            String shortProblemDescriptionRus,
//            String shortProblemDescriptionEng,
//            String longProblemDescriptionRus,
//            String longProblemDescriptionEng,
//            int numbersRangeStart,
//            int numbersRangeEnd,
//            int totalPageOfWorksheets) {
//        this.gradeRus = gradeRus;
//        this.gradeEng = gradeEng;
//        this.h2Rus = h2Rus;
//        this.h2Eng = h2Eng;
//        this.numberRus = numberRus;
//        this.numberEng = numberEng;
//        this.topicRus = topicRus;
//        this.topicEng = topicEng;
//        this.shortProblemDescriptionRus = shortProblemDescriptionRus;
//        this.shortProblemDescriptionEng = shortProblemDescriptionEng;
//        this.longProblemDescriptionRus = longProblemDescriptionRus;
//        this.longProblemDescriptionEng = longProblemDescriptionEng;
//        this.numbersRangeStart = numbersRangeStart;
//        this.numbersRangeEnd = numbersRangeEnd;
//        this.totalPageOfWorksheets = totalPageOfWorksheets;
//    }
}
